class Library:
    def __init__(self, number_of_books):
        self.number_of_books = number_of_books

    def add_book(self, book):
        self.number_of_books += 1
        
    def borrow_book(self, book):
        self.number_of_books -= 1
        
    def show_books(self):
        print(self.number_of_books)

library = Library(0)