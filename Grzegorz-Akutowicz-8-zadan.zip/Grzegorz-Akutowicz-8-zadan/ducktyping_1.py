class Porsche:
    def cena(self):
        price = 900000
        model = "Carrera S"
        print(f"Ten samochód: {model}, kosztuje {price} PLN")

class Mercedes:
    def cena(self):
        price = 500000
        model = "AMG One"
        print(f"Ten samochód: {model}, kosztuje {price} PLN")

class Volkswagen:
    def cena(self):
        price = 100000
        model = "Polo GTI"
        print(f"Ten samochód: {model}, kosztuje {price} PLN")

class Skoda:
    def cena(self):
        price = 80000
        model = "Octavia RS"
        print(f"Ten samochód: {model}, kosztuje {price} PLN")

def pokaz_cene(auto):
    auto.cena()

auta = [Porsche(), Mercedes(), Volkswagen(), Skoda()]

for auto in auta:
    pokaz_cene(auto)