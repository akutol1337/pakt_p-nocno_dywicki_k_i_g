class Warszawa():
    def pogoda(self):
        temp = 10
        warunki = "Lekkie zachmurzenie, lekkie podmuchy wiatru"
        print(f"W Warszawie dzisiejsza temperatura wynosi : { temp } , warunki na dworze: { warunki }")

class Olsztyn():
    def pogoda(self):
        temp = 12
        warunki = "Pochmurnie, silny wiatr"
        print(f"W Olsztynie dzisiejsza temperatura wynosi : { temp } , warunki na dworze: { warunki }")

class Dywity():
    def pogoda(self):
        temp = 12
        warunki = "Pochmurnie, silny wiatr"
        print(f"W Dywitach dzisiejsza temperatura wynosi : { temp } , warunki na dworze: { warunki }")

class Miami():
    def pogoda(self):
        temp = 25
        warunki = "Słonecznie, lekki smog"
        print(f"W Miami dzisiejsza temperatura wynosi : { temp } , warunki na dworze: { warunki }")

class Zakopane():
    def pogoda(self):
        temp = 9
        warunki = "Pada deszcz"
        print(f"W Zakopanem dzisiejsza temperatura wynosi : { temp } , warunki na dworze: { warunki }")

def pokaz_pogode(miejscowosc):
    miejscowosc.pogoda()

miejscowosci = [Warszawa(), Olsztyn(), Dywity(), Miami(), Zakopane()]

for miejscowosc in miejscowosci:
    pokaz_pogode(miejscowosc)