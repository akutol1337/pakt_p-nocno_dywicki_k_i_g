from abc import ABC, abstractmethod
import math

class Figura(ABC):
    @abstractmethod
    def pole(self):
        pass

class Kwadrat(Figura):
    def __init__(self, bok):
        self.bok = bok

    def pole(self):
        return self.bok ** 2

class Kolo(Figura):
    def __init__(self, promien):
        self.promien = promien

    def pole(self):
        return math.pi * self.promien ** 2
    
class Prostokat(Figura):
    def __init__(self, bok, bok2):
        self.bok = bok
        self.bok2 = bok2

    def pole(self):
        return self.bok * self.bok2
    
class Trojkat(Figura):
    def __init__(self, bok, wysokosc):
        self.bok = bok
        self.wysokosc = wysokosc

    def pole (self):
        return 0.5 * self.bok * self.wysokosc    

figury = [Kwadrat(4), Kolo(3), Prostokat(3,5), Trojkat(6,7)]

for figura in figury:
    print(figura.pole())