import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk  # Import PIL for PNG support

okno = tk.Tk()  
okno.title("Zajęcia w FitKlub")
okno.geometry('600x700')
okno.config(bg='#40E0D0')

nagłówek = tk.Label(okno, text="Zajęcia w FitKlub", font=("Times New Roman", 20, "bold"), fg="green")
nagłówek.pack(pady=2)

kanwa = tk.Canvas(
    okno,
    width=366,
    height=243
)
kanwa.pack(pady=2)

imie_i_nazwisko = tk.StringVar()
imie_i_nazwisko_etykieta = tk.Label(okno, text="Imię i nazwisko")
imie_i_nazwisko_etykieta.pack(pady=2)
podaj_imie = tk.Entry(
    okno,
    textvar=imie_i_nazwisko
)
podaj_imie.pack(pady=2)

email = tk.StringVar()
email_etykieta = tk.Label(okno, text="Adres email")
email_etykieta.pack(pady=2)
podaj_email = tk.Entry(
    okno,
    textvar=email
)
podaj_email.pack(pady=2)

opcje = ttk.Combobox(okno)
opcje['values'] = ('pilates', 'salsa', 'zumba', 'aerobic')
opcje.pack(pady=2)

liczba_godzin_w_miesiącu = tk.Label(okno, text="Liczba godzin w miesiącu")
liczba_godzin_w_miesiącu.pack(pady=2)
podaj_liczbę_godzin_w_miesiącu = tk.Spinbox(okno, from_=0, to=20)
podaj_liczbę_godzin_w_miesiącu.pack(pady=2)

stopień_zaawansowania = tk.Label(okno, text="Stopień zaawansowania")
stopień_zaawansowania.pack(pady=2)
stopień = tk.StringVar()
stopień.set("początkujący")
stopień_niski = tk.Radiobutton(okno, text="początkujący", variable=stopień, value="początkujący")
stopień_niski.pack(pady=2)
stopień_średni = tk.Radiobutton(okno, text="średniozaawansowany", variable=stopień, value="średniozaawansowany")
stopień_średni.pack(pady=2)
stopień_wysoki = tk.Radiobutton(okno, text="zaawansowany", variable=stopień, value="zaawansowany")
stopień_wysoki.pack(pady=2)

def klik():
    info = tk.Label(okno, text=('Masz na imię i nazwisko: ' + imie_i_nazwisko.get() + '\nTwój email to: ' + email.get() + '\nLiczba godzin którą chcesz spędzić w FitKlubie wynosi: ' + podaj_liczbę_godzin_w_miesiącu.get() + '\nTwój stopień zaawansowania to stopień: ' + stopień.get()))
    info.pack(pady=10)

zatwierdź = tk.Button(okno, text="Zatwierdź", command=klik)
zatwierdź.pack(pady=2)

# Load PNG image using PIL
obrazek = Image.open('fit.jpg')  # Ensure the path is correct
obrazek = obrazek.resize((366,243))
obrazek = ImageTk.PhotoImage(obrazek)

# Create image on canvas
kanwa.create_image(
    183,
    121,
    image=obrazek
)

okno.mainloop()