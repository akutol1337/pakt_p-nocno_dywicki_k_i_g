class Restaurant:
    def __init__(self, restaurant_name, cuisine_type, opening_time, closing_time):
        self.restaurant_name = restaurant_name
        self.cuisine_type = cuisine_type
        self.opening_time = opening_time
        self.closing_time = closing_time

    def describe_restaurant(self):
        print("Ta restauracja nazywa się: " + self.restaurant_name + ", typ produktu który sprzedaje ta restauracja to: " + self.cuisine_type + "!")

    def open_restaurant(self):
        print("Ta restauracja jest otwarta od: " + self.opening_time + " do: " + self.closing_time + "!")

class IceCreamStand(Restaurant):
    def __init__(self, restaurant_name, cuisine_type, opening_time, closing_time):
        super().__init__(restaurant_name, cuisine_type, opening_time, closing_time)
        self.flavors = []

    def dodaj_smaczek(self, smaczek):
        self.flavors.append(smaczek)

    def pokaż_smaki(self):
        print("Smaki dostępne w tej lodziarni to: ")
        for smak in self.flavors:
            print(smak)

restauracja = Restaurant("Pizza u Wita", "pizza", "6:00", "18:00")

restauracja.describe_restaurant()
restauracja.open_restaurant()

lodziarnia = IceCreamStand("Lody u stacha", "lody", "8:00", "15:00")
lodziarnia.dodaj_smaczek("czekoladowy")
lodziarnia.dodaj_smaczek("Waniliowy")
lodziarnia.dodaj_smaczek("truskawkowy")


lodziarnia.pokaż_smaki()